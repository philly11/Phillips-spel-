#include "game.h"

int main()
{
    pgame::Game game;
    game.Run();

    return 0;
}