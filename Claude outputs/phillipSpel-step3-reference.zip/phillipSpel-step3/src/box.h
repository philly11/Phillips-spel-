#pragma once

namespace pgame
{

struct Box
{
    float x, y, z;              // Position of the box
    float width, height, depth; // Dimensions of the box
};
} // namespace pgame
