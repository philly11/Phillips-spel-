#include <doctest/doctest.h>

#include "weapon.h"

using namespace pgame;

namespace
{
// Small, round numbers so the tests are easy to reason about
WeaponConfig MakeConfig()
{
    WeaponConfig c;
    c.fireInterval = 0.1f;
    c.magazineSize = 3;
    c.reserveAmmo = 5;
    c.reloadTime = 1.0f;
    c.baseSpread = 0.01f;
    c.spreadPerShot = 0.02f;
    c.maxSpread = 0.05f;
    c.spreadRecovery = 0.1f;
    return c;
}
} // namespace

TEST_CASE("Weapon starts with a full magazine and the configured reserve")
{
    const Weapon w(MakeConfig());
    CHECK(w.GetAmmoInMagazine() == 3);
    CHECK(w.GetReserveAmmo() == 5);
    CHECK_FALSE(w.IsReloading());
}

TEST_CASE("Firing uses one bullet")
{
    Weapon w(MakeConfig());
    REQUIRE(w.TryFire());
    CHECK(w.GetAmmoInMagazine() == 2);
}

TEST_CASE("Cannot fire again until the fire interval has passed")
{
    Weapon w(MakeConfig());
    REQUIRE(w.TryFire());
    CHECK_FALSE(w.TryFire());

    w.Update(0.05f);
    CHECK_FALSE(w.TryFire());

    w.Update(0.05f);
    CHECK(w.TryFire());
}

TEST_CASE("Empty magazine starts a reload instead of firing")
{
    Weapon w(MakeConfig());
    for (int i = 0; i < 3; ++i)
    {
        REQUIRE(w.TryFire());
        w.Update(0.1f);
    }
    REQUIRE(w.GetAmmoInMagazine() == 0);

    CHECK_FALSE(w.TryFire());
    CHECK(w.IsReloading());
}

TEST_CASE("Reload moves bullets from reserve into the magazine")
{
    Weapon w(MakeConfig());
    REQUIRE(w.TryFire());
    w.StartReload();
    REQUIRE(w.IsReloading());

    w.Update(1.0f);
    CHECK_FALSE(w.IsReloading());
    CHECK(w.GetAmmoInMagazine() == 3);
    CHECK(w.GetReserveAmmo() == 4);
}

TEST_CASE("Reload is ignored when the magazine is already full")
{
    Weapon w(MakeConfig());
    w.StartReload();
    CHECK_FALSE(w.IsReloading());
}

TEST_CASE("Spread starts at base spread")
{
    const Weapon w(MakeConfig());
    CHECK(w.GetCurrentSpread() == doctest::Approx(0.01f));
}

TEST_CASE("Firing blooms the spread, but the shot uses the spread from before")
{
    Weapon w(MakeConfig());
    REQUIRE(w.TryFire());
    CHECK(w.GetShotSpread() == doctest::Approx(0.01f));
    CHECK(w.GetCurrentSpread() == doctest::Approx(0.03f));
}

TEST_CASE("Spread never goes above max spread")
{
    WeaponConfig c = MakeConfig();
    c.spreadRecovery = 0.0f; // no recovery, so every shot adds the full bloom
    Weapon w(c);

    // 0.01 -> 0.03 -> 0.05 -> would be 0.07, but is capped
    for (int i = 0; i < 3; ++i)
    {
        REQUIRE(w.TryFire());
        w.Update(0.1f);
    }
    CHECK(w.GetCurrentSpread() == doctest::Approx(0.05f));
}

TEST_CASE("Spread recovers back to base spread")
{
    Weapon w(MakeConfig());
    REQUIRE(w.TryFire());
    w.Update(10.0f);
    CHECK(w.GetCurrentSpread() == doctest::Approx(0.01f));
}
