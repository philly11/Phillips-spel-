#include <doctest/doctest.h>

#include "target.h"

using namespace pgame;

namespace
{
const Box kBox{0.0f, 0.0f, 0.0f, 1.0f, 2.0f, 1.0f}; // center (0, 0), y = bottom
constexpr float kDt = 0.016f;
const Vec3 kNear{1.0f, 1.7f, 0.0f};
const Vec3 kFar{10.0f, 1.7f, 0.0f};
} // namespace

TEST_CASE("Target does not attack when out of range")
{
    Target t(kBox, 3);
    CHECK_FALSE(t.TryAttack(kDt, kFar));
}

TEST_CASE("Target attacks when in range and cooldown is ready")
{
    Target t(kBox, 3);
    CHECK(t.TryAttack(kDt, kNear));
}

TEST_CASE("Target attacks at exactly attack range")
{
    Target t(kBox, 3);
    CHECK(t.TryAttack(kDt, {Target::kAttackRange, 1.7f, 0.0f}));
}

TEST_CASE("Target does not attack again before cooldown ends")
{
    Target t(kBox, 3);
    REQUIRE(t.TryAttack(kDt, kNear));
    CHECK_FALSE(t.TryAttack(kDt, kNear));
    CHECK_FALSE(t.TryAttack(Target::kAttackInterval * 0.5f, kNear));
}

TEST_CASE("Target attacks again after cooldown ends")
{
    Target t(kBox, 3);
    REQUIRE(t.TryAttack(kDt, kNear));
    CHECK(t.TryAttack(Target::kAttackInterval, kNear));
}

TEST_CASE("Dead target never attacks")
{
    Target t(kBox, 3);
    t.TakeDamage(3);
    REQUIRE_FALSE(t.IsAlive());
    CHECK_FALSE(t.TryAttack(kDt, kNear));
}
