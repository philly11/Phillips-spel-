#include <cmath>
#include <doctest/doctest.h>

#include "player.h"

using namespace pgame;

static const float kDt = 1.0f / 60.0f; // 60 FPS

static float Distance(const Vec3 &a, const Vec3 &b)
{
    return std::sqrt((a.x - b.x) * (a.x - b.x) + (a.z - b.z) * (a.z - b.z));
}

TEST_CASE("standing still on ")
{
    Player player;
    const Vec3 start = player.GetPosition();
    for (int i = 0; i < 60; ++i)
        player.Update(PlayerInput{}, kDt, 0.0f);

    CHECK(player.GetPosition().y == doctest::Approx(start.y));
    CHECK(player.IsOnGround());
}

TEST_CASE("forward input moves along +Z at yaw 0")
{
    Player player;
    const Vec3 start = player.GetPosition();
    PlayerInput input;
    input.moveForward = 1.0f;
    player.Update(input, kDt, 0.0f);
    CHECK(player.GetPosition().z > start.z);
    CHECK(player.GetPosition().x == doctest::Approx(start.x));
}

TEST_CASE("diagonal movement is not faster than straight")
{
    Player straight, diagonal;
    const Vec3 s0 = straight.GetPosition();
    const Vec3 d0 = diagonal.GetPosition();

    PlayerInput a;
    a.moveForward = 1.0f;
    PlayerInput b;
    b.moveForward = 1.0f;
    b.moveRight = 1.0f;

    straight.Update(a, kDt, 0.0f);
    diagonal.Update(b, kDt, 0.0f);

    CHECK(Distance(s0, straight.GetPosition()) ==
          doctest::Approx(Distance(d0, diagonal.GetPosition())));
}

TEST_CASE("jumping leaves ground and land")
{
    Player player;
    PlayerInput jump;
    jump.jump = true;
    jump.jumpHeld = true;
    player.Update(jump, kDt, 0.0f);

    REQUIRE_FALSE(player.IsOnGround());
    CHECK(player.GetVelocityY() > 0.0f);

    for (int i = 0; i < 180; ++i)
        player.Update(PlayerInput{}, kDt, 0.0f);

    CHECK(player.IsOnGround());
    CHECK(player.GetPosition().y == doctest::Approx(1.7f));
}
TEST_CASE("Player starts at max health")
{
    Player p;
    CHECK(p.GetHealth() == Player::kMaxHealth);
    CHECK(p.IsAlive());
}

TEST_CASE("Player TakeDamage reduces health")
{
    Player p;
    p.TakeDamage(30);
    CHECK(p.GetHealth() == Player::kMaxHealth - 30);
}

TEST_CASE("Player dies at zero health and health never goes negative")
{
    Player p;
    p.TakeDamage(Player::kMaxHealth + 50);
    CHECK(p.GetHealth() == 0);
    CHECK_FALSE(p.IsAlive());
}

TEST_CASE("recoil kicks the view up")
{
    Player player;
    const float before = player.GetLookDirection().y;
    player.AddRecoil(0.1f, 0.0f);
    CHECK(player.GetLookDirection().y > before);
}

TEST_CASE("recoil recovers back to the original aim")
{
    Player player;
    const Vec3 before = player.GetLookDirection();
    player.AddRecoil(0.1f, 0.05f);

    for (int i = 0; i < 300; ++i) // 5 seconds, far longer than recovery needs
        player.Update(PlayerInput{}, kDt, 0.0f);

    const Vec3 after = player.GetLookDirection();
    CHECK(after.x == doctest::Approx(before.x));
    CHECK(after.y == doctest::Approx(before.y));
    CHECK(after.z == doctest::Approx(before.z));
}
