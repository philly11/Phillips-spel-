#include <cmath>
#include <doctest/doctest.h>

#include "spread.h"

using namespace pgame;

namespace
{
const Vec3 kForward{0.0f, 0.0f, 1.0f};

float Length(const Vec3 &v)
{
    return std::sqrt(v.x * v.x + v.y * v.y + v.z * v.z);
}
float Dot(const Vec3 &a, const Vec3 &b)
{
    return a.x * b.x + a.y * b.y + a.z * b.z;
}
} // namespace

TEST_CASE("Zero spread returns the aim direction unchanged")
{
    const Vec3 d = ApplySpread(kForward, 0.0f, 0.3f, 0.7f);
    CHECK(d.x == doctest::Approx(0.0f));
    CHECK(d.y == doctest::Approx(0.0f));
    CHECK(d.z == doctest::Approx(1.0f));
}

TEST_CASE("Spread result is always a unit vector")
{
    const Vec3 d = ApplySpread(kForward, 0.1f, 0.25f, 0.9f);
    CHECK(Length(d) == doctest::Approx(1.0f));
}

TEST_CASE("Spread never goes further off-aim than the spread angle")
{
    const float spread = 0.1f;
    // v = 1 is the edge of the disc, the worst case
    for (float u = 0.0f; u < 1.0f; u += 0.125f)
    {
        const Vec3 d = ApplySpread(kForward, spread, u, 1.0f);
        const float angle = std::acos(Dot(d, kForward));
        CHECK(angle <= spread + 1e-4f);
    }
}

TEST_CASE("Spread works when aiming straight up")
{
    const Vec3 d = ApplySpread({0.0f, 1.0f, 0.0f}, 0.1f, 0.5f, 0.5f);
    CHECK(Length(d) == doctest::Approx(1.0f));
}
