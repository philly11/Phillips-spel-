#include <doctest/doctest.h>
#include <vector>

#include "combat.h"

using namespace pgame;

namespace
{
constexpr float kMaxDistance = 100.0f;

// Shoots from the origin straight along +Z, at chest height
const Ray kRay{{0.0f, 1.0f, 0.0f}, {0.0f, 0.0f, 1.0f}};

//                                       x     y     z     w     h     d
Target MakeTargetAt(float z)
{
    return Target(Box{0.0f, 0.0f, z, 1.0f, 2.0f, 1.0f}, 3);
}
Box MakeWallAt(float z)
{
    return Box{0.0f, 0.0f, z, 4.0f, 3.0f, 0.5f};
}
} // namespace

TEST_CASE("Shot into empty space hits nothing")
{
    const Map map(std::vector<Box>{});
    const ShotResult shot = ResolveShot(kRay, map, {}, kMaxDistance);
    CHECK(shot.kind == ShotResult::Kind::None);
}

TEST_CASE("Shot hits a target in the open")
{
    const Map map(std::vector<Box>{});
    const std::vector<Target> targets{MakeTargetAt(5.0f)};

    const ShotResult shot = ResolveShot(kRay, map, targets, kMaxDistance);
    CHECK(shot.kind == ShotResult::Kind::Target);
    CHECK(shot.targetIndex == 0);
    CHECK(shot.distance == doctest::Approx(4.5f)); // front face of the box
}

TEST_CASE("A wall in front of a target blocks the shot")
{
    const Map map({MakeWallAt(3.0f)});
    const std::vector<Target> targets{MakeTargetAt(5.0f)};

    const ShotResult shot = ResolveShot(kRay, map, targets, kMaxDistance);
    CHECK(shot.kind == ShotResult::Kind::Wall);
}

TEST_CASE("A target in front of a wall is hit")
{
    const Map map({MakeWallAt(8.0f)});
    const std::vector<Target> targets{MakeTargetAt(5.0f)};

    const ShotResult shot = ResolveShot(kRay, map, targets, kMaxDistance);
    CHECK(shot.kind == ShotResult::Kind::Target);
}

TEST_CASE("The nearest of several targets is hit")
{
    const Map map(std::vector<Box>{});
    const std::vector<Target> targets{MakeTargetAt(9.0f), MakeTargetAt(4.0f)};

    const ShotResult shot = ResolveShot(kRay, map, targets, kMaxDistance);
    CHECK(shot.kind == ShotResult::Kind::Target);
    CHECK(shot.targetIndex == 1);
}

TEST_CASE("Dead targets are shot through")
{
    const Map map(std::vector<Box>{});
    std::vector<Target> targets{MakeTargetAt(4.0f), MakeTargetAt(9.0f)};
    targets[0].TakeDamage(3);

    const ShotResult shot = ResolveShot(kRay, map, targets, kMaxDistance);
    CHECK(shot.kind == ShotResult::Kind::Target);
    CHECK(shot.targetIndex == 1);
}

TEST_CASE("Targets beyond max distance are not hit")
{
    const Map map(std::vector<Box>{});
    const std::vector<Target> targets{MakeTargetAt(50.0f)};

    const ShotResult shot = ResolveShot(kRay, map, targets, 10.0f);
    CHECK(shot.kind == ShotResult::Kind::None);
}
